import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { PageLayout } from '@/components/layout/PageLayout';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useJournal } from '@/hooks/useJournal';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2, Send, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';

const Journal = () => {
  const { user, loading: authLoading } = useAuth();
  const { entries, loading, addEntry, deleteEntry } = useJournal();
  const [text, setText] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!text.trim()) return;
    setSaving(true);
    const success = await addEntry(text);
    if (success) {
      setText('');
    }
    setSaving(false);
  };

  if (authLoading) {
    return (
      <PageLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </PageLayout>
    );
  }

  if (!user) {
    return (
      <PageLayout>
        <div className="container mx-auto px-4 py-12 text-center">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <span className="text-3xl">📓</span>
            </div>
            <h1 className="text-2xl font-bold mb-4">Sign in to Journal</h1>
            <p className="text-muted-foreground mb-6">
              Create an account to save your reflections and insights.
            </p>
            <Link to="/login">
              <Button>Sign In</Button>
            </Link>
          </div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold mb-2">Journal</h1>
          <p className="text-muted-foreground">
            Capture your reflections, insights, and breakthroughs.
          </p>
        </motion.div>

        {/* New Entry */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl p-6 mb-8"
        >
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="What's on your mind today? Reflect on your journey, capture insights, or process your thoughts..."
            className="min-h-[150px] resize-none mb-4"
          />
          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={!text.trim() || saving}>
              {saving ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Send className="w-4 h-4 mr-2" />
              )}
              Save Entry
            </Button>
          </div>
        </motion.div>

        {/* Entries List */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-muted-foreground">
            Recent Entries
          </h2>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : entries.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>No entries yet. Start journaling above!</p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              {entries.map((entry, index) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-card border border-border rounded-xl p-5 group"
                >
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <time className="text-sm text-muted-foreground">
                      {format(new Date(entry.created_at), 'MMM d, yyyy • h:mm a')}
                    </time>
                    <button
                      onClick={() => deleteEntry(entry.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-destructive/10 rounded"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                  <p className="text-secondary-foreground whitespace-pre-wrap leading-relaxed">
                    {entry.text}
                  </p>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </div>
      </div>
    </PageLayout>
  );
};

export default Journal;
