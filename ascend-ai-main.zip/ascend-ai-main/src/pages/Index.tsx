import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PageLayout } from '@/components/layout/PageLayout';
import { AgentCard } from '@/components/cards/AgentCard';
import { Button } from '@/components/ui/button';
import { agents } from '@/data/agents';
import { useAuth } from '@/contexts/AuthContext';
import { LayoutDashboard, MessageSquare, BookOpen, Sparkles } from 'lucide-react';

const Index = () => {
  const { user } = useAuth();

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-12">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">3 Agents • 30 Pillars • Infinite Growth</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-foreground">Major</span>{' '}
            <span className="text-gradient-money">AI</span>{' '}
            <span className="text-foreground">Trinity</span>
          </h1>
          
          <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
            Three AI agents. Three frameworks. One transformative journey.
            Master your life, wealth, and technology with personalized guidance.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/dashboard">
              <Button size="lg" className="gap-2">
                <LayoutDashboard className="w-4 h-4" />
                View Dashboard
              </Button>
            </Link>
            <Link to="/agent-chat">
              <Button size="lg" variant="outline" className="gap-2">
                <MessageSquare className="w-4 h-4" />
                Chat with Agents
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Agents Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="grid md:grid-cols-3 gap-6 mb-16"
        >
          {agents.map((agent, index) => (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <Link to="/agent-chat">
                <AgentCard agent={agent} />
              </Link>
            </motion.div>
          ))}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-card border border-border rounded-2xl p-8 text-center"
        >
          <h2 className="text-2xl font-semibold mb-4">Begin Your Journey</h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            Track your progress through 30 pillars, journal your insights, 
            and get personalized guidance from your AI agents.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/dashboard">
              <Button variant="secondary" className="gap-2">
                <LayoutDashboard className="w-4 h-4" />
                Track Pillars
              </Button>
            </Link>
            <Link to="/journal">
              <Button variant="secondary" className="gap-2">
                <BookOpen className="w-4 h-4" />
                Write Journal
              </Button>
            </Link>
            {!user && (
              <Link to="/login">
                <Button variant="default" className="gap-2">
                  Get Started Free
                </Button>
              </Link>
            )}
          </div>
        </motion.div>
      </div>
    </PageLayout>
  );
};

export default Index;
