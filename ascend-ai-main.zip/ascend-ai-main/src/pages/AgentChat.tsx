import { PageLayout } from '@/components/layout/PageLayout';
import { ChatInterface } from '@/components/chat/ChatInterface';

const AgentChat = () => {
  return (
    <PageLayout>
      <div className="container mx-auto px-4">
        <ChatInterface />
      </div>
    </PageLayout>
  );
};

export default AgentChat;
