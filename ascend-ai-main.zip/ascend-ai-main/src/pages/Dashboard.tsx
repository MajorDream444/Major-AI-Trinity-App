import { useState } from 'react';
import { motion } from 'framer-motion';
import { PageLayout } from '@/components/layout/PageLayout';
import { PillarCard } from '@/components/cards/PillarCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { getFrameworkPillars, pillars } from '@/data/pillars';
import { useProgress } from '@/hooks/useProgress';
import { useAuth } from '@/contexts/AuthContext';
import { Heart, DollarSign, Cpu, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const frameworks = [
  { id: 'life', label: 'LIFE', icon: Heart, agent: 'PILLAR' },
  { id: 'money', label: 'MONEY', icon: DollarSign, agent: 'COME-UP' },
  { id: 'tech', label: 'TECH', icon: Cpu, agent: 'CODEX' },
] as const;

const Dashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const { completedPillars, loading: progressLoading, togglePillar, completedCount } = useProgress();
  const [activeTab, setActiveTab] = useState<string>('life');

  const totalPillars = pillars.length;
  const progressPercent = (completedCount / totalPillars) * 100;

  if (authLoading) {
    return (
      <PageLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </PageLayout>
    );
  }

  if (!user) {
    return (
      <PageLayout>
        <div className="container mx-auto px-4 py-12 text-center">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <span className="text-3xl">🔒</span>
            </div>
            <h1 className="text-2xl font-bold mb-4">Sign in to Track Progress</h1>
            <p className="text-muted-foreground mb-6">
              Create an account to save your progress across all 30 pillars.
            </p>
            <Link to="/login">
              <Button>Sign In</Button>
            </Link>
          </div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold mb-2">Your Dashboard</h1>
          <p className="text-muted-foreground">
            Track your journey through the 30 pillars of transformation.
          </p>
        </motion.div>

        {/* Progress Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl p-6 mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold">Total Progress</h2>
              <p className="text-muted-foreground text-sm">
                {completedCount} of {totalPillars} pillars completed
              </p>
            </div>
            <div className="text-3xl font-bold text-primary">
              {Math.round(progressPercent)}%
            </div>
          </div>
          <Progress value={progressPercent} className="h-3" />
        </motion.div>

        {/* Framework Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            {frameworks.map(({ id, label, icon: Icon }) => {
              const frameworkPillars = getFrameworkPillars(id as 'life' | 'money' | 'tech');
              const frameworkCompleted = frameworkPillars.filter(p => 
                completedPillars.includes(p.id)
              ).length;
              
              return (
                <TabsTrigger key={id} value={id} className="gap-2">
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{label}</span>
                  <span className="text-xs text-muted-foreground ml-1">
                    {frameworkCompleted}/10
                  </span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {frameworks.map(({ id, agent }) => {
            const frameworkPillars = getFrameworkPillars(id as 'life' | 'money' | 'tech');
            
            return (
              <TabsContent key={id} value={id}>
                <div className="mb-4 flex items-center justify-between">
                  <h3 className={`text-xl font-semibold text-gradient-${id}`}>
                    {agent} Framework
                  </h3>
                  <span className="text-sm text-muted-foreground">
                    10 Pillars
                  </span>
                </div>
                
                <div className="space-y-3">
                  {progressLoading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-6 h-6 animate-spin text-primary" />
                    </div>
                  ) : (
                    frameworkPillars.map((pillar, index) => (
                      <PillarCard
                        key={pillar.id}
                        pillar={pillar}
                        isCompleted={completedPillars.includes(pillar.id)}
                        onToggle={() => togglePillar(pillar.id)}
                        index={index}
                      />
                    ))
                  )}
                </div>
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </PageLayout>
  );
};

export default Dashboard;
