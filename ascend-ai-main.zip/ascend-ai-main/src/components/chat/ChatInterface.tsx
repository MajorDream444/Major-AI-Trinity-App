import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, RotateCcw, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { agents, Agent } from '@/data/agents';
import { useChat } from '@/hooks/useChat';
import { useAuth } from '@/contexts/AuthContext';

export function ChatInterface() {
  const { user } = useAuth();
  const [selectedAgent, setSelectedAgent] = useState<Agent>(agents[0]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { messages, sending, sendMessage, newChat } = useChat();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim() || sending) return;
    sendMessage(input, selectedAgent.id);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center px-4">
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
          <span className="text-3xl">💬</span>
        </div>
        <h2 className="text-xl font-semibold mb-2">Sign in to Chat</h2>
        <p className="text-muted-foreground">
          Connect with your AI agents after signing in.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      {/* Agent Selector */}
      <div className="flex items-center gap-2 p-4 border-b border-border overflow-x-auto">
        {agents.map((agent) => (
          <Button
            key={agent.id}
            variant={selectedAgent.id === agent.id ? 'default' : 'outline'}
            size="sm"
            onClick={() => {
              setSelectedAgent(agent);
              newChat(agent.id);
            }}
            className="shrink-0"
          >
            {agent.name}
          </Button>
        ))}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => newChat(selectedAgent.id)}
          className="ml-auto shrink-0"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          New Chat
        </Button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-12">
            <div className={`w-16 h-16 mx-auto rounded-2xl bg-${selectedAgent.framework}/10 flex items-center justify-center mb-4`}>
              <span className="text-3xl">
                {selectedAgent.id === 'pillar' ? '🏛️' : selectedAgent.id === 'comeup' ? '💰' : '⚡'}
              </span>
            </div>
            <h3 className={`text-lg font-semibold text-gradient-${selectedAgent.framework}`}>
              {selectedAgent.name}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {selectedAgent.archetype}
            </p>
            <p className="text-sm text-secondary-foreground mt-4 max-w-md mx-auto">
              {selectedAgent.persona}
            </p>
          </div>
        )}

        <AnimatePresence mode="popLayout">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.text}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {sending && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-start"
          >
            <div className="bg-secondary rounded-2xl px-4 py-3">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Message ${selectedAgent.name}...`}
            className="min-h-[44px] max-h-32 resize-none"
            rows={1}
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || sending}
            size="icon"
            className="shrink-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
