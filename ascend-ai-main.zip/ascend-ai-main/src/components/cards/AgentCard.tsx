import { motion } from 'framer-motion';
import { Agent } from '@/data/agents';
import { Heart, DollarSign, Cpu } from 'lucide-react';

interface AgentCardProps {
  agent: Agent;
  onClick?: () => void;
}

const icons = {
  life: Heart,
  money: DollarSign,
  tech: Cpu,
};

export function AgentCard({ agent, onClick }: AgentCardProps) {
  const Icon = icons[agent.framework];
  const cardClass = `agent-card-${agent.framework}`;

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`${cardClass} rounded-2xl p-6 cursor-pointer transition-all duration-300`}
    >
      <div className="flex items-start gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-${agent.framework}/20`}>
          <Icon className={`w-6 h-6 text-${agent.framework}`} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className={`text-xl font-bold text-gradient-${agent.framework}`}>
            {agent.name}
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            {agent.archetype}
          </p>
        </div>
      </div>
      
      <p className="mt-4 text-sm text-secondary-foreground leading-relaxed">
        {agent.description}
      </p>

      <div className="mt-4 pt-4 border-t border-border/50">
        <span className="text-xs text-muted-foreground uppercase tracking-wider">
          {agent.framework} Framework
        </span>
      </div>
    </motion.div>
  );
}
