import { motion } from 'framer-motion';
import { Pillar } from '@/data/pillars';
import { Checkbox } from '@/components/ui/checkbox';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface PillarCardProps {
  pillar: Pillar;
  isCompleted: boolean;
  onToggle: () => void;
  index: number;
}

export function PillarCard({ pillar, isCompleted, onToggle, index }: PillarCardProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`pillar-card ${isCompleted ? 'border-primary/40 bg-primary/5' : ''}`}
    >
      <div className="flex items-start gap-4">
        <Checkbox
          checked={isCompleted}
          onCheckedChange={onToggle}
          className="mt-1"
        />
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h4 className={`font-semibold ${isCompleted ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
              {pillar.name}
            </h4>
            <button
              onClick={() => setExpanded(!expanded)}
              className="p-1 hover:bg-secondary rounded-md transition-colors"
            >
              {expanded ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              )}
            </button>
          </div>
          
          <p className="text-sm text-muted-foreground mt-1">
            {pillar.tagline}
          </p>

          {expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 space-y-3"
            >
              <div>
                <span className="text-xs uppercase tracking-wider text-primary">Reflection</span>
                <p className="text-sm text-secondary-foreground mt-1 italic">
                  "{pillar.reflectionPrompt}"
                </p>
              </div>
              
              <div>
                <span className="text-xs uppercase tracking-wider text-primary">Major Move</span>
                <p className="text-sm text-secondary-foreground mt-1">
                  {pillar.majorMove}
                </p>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
