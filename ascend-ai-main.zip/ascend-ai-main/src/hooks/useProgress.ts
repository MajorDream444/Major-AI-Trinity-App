import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export function useProgress() {
  const { user } = useAuth();
  const [completedPillars, setCompletedPillars] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchProgress();
    } else {
      setCompletedPillars([]);
      setLoading(false);
    }
  }, [user]);

  const fetchProgress = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('progress')
        .select('completed_pillars')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching progress:', error);
        return;
      }

      setCompletedPillars(data?.completed_pillars || []);
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const togglePillar = useCallback(async (pillarId: string) => {
    if (!user) {
      toast.error('Please sign in to track progress');
      return;
    }

    const isCompleted = completedPillars.includes(pillarId);
    const newCompleted = isCompleted
      ? completedPillars.filter(id => id !== pillarId)
      : [...completedPillars, pillarId];

    // Optimistic update
    setCompletedPillars(newCompleted);

    try {
      const { error } = await supabase
        .from('progress')
        .upsert({
          user_id: user.id,
          completed_pillars: newCompleted,
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;

      if (!isCompleted) {
        toast.success('Pillar completed! 🎉');
      }
    } catch (err) {
      // Revert on error
      setCompletedPillars(completedPillars);
      console.error('Error updating progress:', err);
      toast.error('Failed to update progress');
    }
  }, [user, completedPillars]);

  return {
    completedPillars,
    loading,
    togglePillar,
    completedCount: completedPillars.length,
  };
}
