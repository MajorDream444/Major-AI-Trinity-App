import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface JournalEntry {
  id: string;
  text: string;
  created_at: string;
}

export function useJournal() {
  const { user } = useAuth();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchEntries();
    } else {
      setEntries([]);
      setLoading(false);
    }
  }, [user]);

  const fetchEntries = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setEntries(data || []);
    } catch (err) {
      console.error('Error fetching entries:', err);
      toast.error('Failed to load journal entries');
    } finally {
      setLoading(false);
    }
  };

  const addEntry = useCallback(async (text: string) => {
    if (!user) {
      toast.error('Please sign in to save journal entries');
      return false;
    }

    if (!text.trim()) {
      toast.error('Please write something first');
      return false;
    }

    try {
      const { data, error } = await supabase
        .from('journal_entries')
        .insert({
          user_id: user.id,
          text: text.trim(),
        })
        .select()
        .single();

      if (error) throw error;

      setEntries(prev => [data, ...prev]);
      toast.success('Entry saved! 📝');
      return true;
    } catch (err) {
      console.error('Error saving entry:', err);
      toast.error('Failed to save entry');
      return false;
    }
  }, [user]);

  const deleteEntry = useCallback(async (entryId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('journal_entries')
        .delete()
        .eq('id', entryId);

      if (error) throw error;

      setEntries(prev => prev.filter(e => e.id !== entryId));
      toast.success('Entry deleted');
    } catch (err) {
      console.error('Error deleting entry:', err);
      toast.error('Failed to delete entry');
    }
  }, [user]);

  return {
    entries,
    loading,
    addEntry,
    deleteEntry,
  };
}
