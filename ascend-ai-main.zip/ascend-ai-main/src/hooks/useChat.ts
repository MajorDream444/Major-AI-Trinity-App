import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  created_at: string;
}

interface Thread {
  id: string;
  agent_id: string;
  created_at: string;
}

export function useChat() {
  const { user } = useAuth();
  const [currentThread, setCurrentThread] = useState<Thread | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  const createThread = useCallback(async (agentId: string) => {
    if (!user) {
      toast.error('Please sign in to chat');
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('chat_threads')
        .insert({
          user_id: user.id,
          agent_id: agentId,
        })
        .select()
        .single();

      if (error) throw error;

      setCurrentThread(data);
      setMessages([]);
      return data;
    } catch (err) {
      console.error('Error creating thread:', err);
      toast.error('Failed to start chat');
      return null;
    }
  }, [user]);

  const loadThread = useCallback(async (threadId: string) => {
    setLoading(true);
    try {
      const { data: thread, error: threadError } = await supabase
        .from('chat_threads')
        .select('*')
        .eq('id', threadId)
        .single();

      if (threadError) throw threadError;

      const { data: msgs, error: msgsError } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('thread_id', threadId)
        .order('created_at', { ascending: true });

      if (msgsError) throw msgsError;

      setCurrentThread(thread);
      setMessages(msgs || []);
    } catch (err) {
      console.error('Error loading thread:', err);
      toast.error('Failed to load conversation');
    } finally {
      setLoading(false);
    }
  }, []);

  const sendMessage = useCallback(async (text: string, agentId: string, pillarId?: string) => {
    if (!user) {
      toast.error('Please sign in to chat');
      return;
    }

    if (!text.trim()) return;

    let threadToUse = currentThread;

    // Create new thread if needed
    if (!threadToUse || threadToUse.agent_id !== agentId) {
      threadToUse = await createThread(agentId);
      if (!threadToUse) return;
    }

    setSending(true);

    // Add user message optimistically
    const tempUserMsg: Message = {
      id: `temp-${Date.now()}`,
      role: 'user',
      text: text.trim(),
      created_at: new Date().toISOString(),
    };
    setMessages(prev => [...prev, tempUserMsg]);

    try {
      // Save user message
      const { data: savedUserMsg, error: userMsgError } = await supabase
        .from('chat_messages')
        .insert({
          thread_id: threadToUse.id,
          role: 'user',
          text: text.trim(),
        })
        .select()
        .single();

      if (userMsgError) throw userMsgError;

      // Update with real message
      setMessages(prev => prev.map(m => 
        m.id === tempUserMsg.id ? savedUserMsg : m
      ));

      // Get recent messages for context (last 10)
      const recentMessages = [...messages.slice(-10), { role: 'user', text: text.trim() }];

      // Call AI
      const response = await supabase.functions.invoke('agent-chat', {
        body: {
          agentId,
          userMessage: text.trim(),
          recentMessages: recentMessages.map(m => ({ role: m.role, content: m.text })),
          pillarId,
        },
      });

      if (response.error) throw response.error;

      const assistantText = response.data?.text || "I'm having trouble responding right now. Please try again.";

      // Save assistant message
      const { data: savedAssistantMsg, error: assistantMsgError } = await supabase
        .from('chat_messages')
        .insert({
          thread_id: threadToUse.id,
          role: 'assistant',
          text: assistantText,
        })
        .select()
        .single();

      if (assistantMsgError) throw assistantMsgError;

      setMessages(prev => [...prev, savedAssistantMsg]);
    } catch (err: any) {
      console.error('Error sending message:', err);
      // Remove temp message on error
      setMessages(prev => prev.filter(m => m.id !== tempUserMsg.id));
      
      if (err.message?.includes('429')) {
        toast.error('Rate limit reached. Please wait a moment.');
      } else if (err.message?.includes('402')) {
        toast.error('Usage limit reached. Please try again later.');
      } else {
        toast.error('Failed to send message');
      }
    } finally {
      setSending(false);
    }
  }, [user, currentThread, messages, createThread]);

  const newChat = useCallback((agentId: string) => {
    setCurrentThread(null);
    setMessages([]);
  }, []);

  return {
    currentThread,
    messages,
    loading,
    sending,
    sendMessage,
    newChat,
    loadThread,
    createThread,
  };
}
