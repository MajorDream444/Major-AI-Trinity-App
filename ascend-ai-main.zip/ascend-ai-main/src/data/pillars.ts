export interface Pillar {
  id: string;
  name: string;
  framework: 'life' | 'money' | 'tech';
  tagline: string;
  reflectionPrompt: string;
  majorMove: string;
}

export const pillars: Pillar[] = [
  // LIFE Framework - PILLAR (The Inner Architect)
  {
    id: 'life-01',
    name: 'Mindset Mastery',
    framework: 'life',
    tagline: 'Your thoughts shape your world.',
    reflectionPrompt: 'What limiting belief are you ready to release today?',
    majorMove: 'Write down one negative thought pattern and rewrite it as an empowering statement.'
  },
  {
    id: 'life-02',
    name: 'Entrepreneurial Skill-Building',
    framework: 'life',
    tagline: 'Build skills that build wealth.',
    reflectionPrompt: 'What skill would 10x your earning potential?',
    majorMove: 'Spend 30 minutes learning one marketable skill today.'
  },
  {
    id: 'life-03',
    name: 'Cultural Connection & Identity',
    framework: 'life',
    tagline: 'Know where you come from.',
    reflectionPrompt: 'How does your heritage inform your purpose?',
    majorMove: 'Research one aspect of your ancestry and journal about its meaning.'
  },
  {
    id: 'life-04',
    name: 'Physical Vitality',
    framework: 'life',
    tagline: 'Energy is currency.',
    reflectionPrompt: 'How are you investing in your body today?',
    majorMove: 'Move your body for at least 20 minutes with intention.'
  },
  {
    id: 'life-05',
    name: 'Nutritional Resilience',
    framework: 'life',
    tagline: 'Fuel your vision.',
    reflectionPrompt: 'Are you eating to survive or thrive?',
    majorMove: 'Replace one processed meal with whole foods today.'
  },
  {
    id: 'life-06',
    name: 'Digital Wealth Creation',
    framework: 'life',
    tagline: 'Own your online presence.',
    reflectionPrompt: 'Is your digital footprint building or blocking wealth?',
    majorMove: 'Audit one social profile and optimize it for opportunity.'
  },
  {
    id: 'life-07',
    name: 'Community Connection & Networking',
    framework: 'life',
    tagline: 'Your network is your net worth.',
    reflectionPrompt: 'Who lifts you higher?',
    majorMove: 'Reach out to one person who inspires you and start a conversation.'
  },
  {
    id: 'life-08',
    name: 'Wisdom & Storytelling',
    framework: 'life',
    tagline: 'Stories carry power.',
    reflectionPrompt: 'What story are you telling yourself about your life?',
    majorMove: 'Share one lesson you learned this week with someone who needs it.'
  },
  {
    id: 'life-09',
    name: 'Forgiveness & Gratitude',
    framework: 'life',
    tagline: 'Release to receive.',
    reflectionPrompt: "What burden are you carrying that isn't yours?",
    majorMove: 'Write a forgiveness letter (send it or burn it) and list 3 gratitudes.'
  },
  {
    id: 'life-10',
    name: 'Creative Expression',
    framework: 'life',
    tagline: 'Create without permission.',
    reflectionPrompt: 'When did you last make something just for you?',
    majorMove: 'Spend 15 minutes creating without judgment—write, draw, build.'
  },

  // MONEY Framework - COME-UP (The Financial Prophet)
  {
    id: 'money-01',
    name: 'Measure',
    framework: 'money',
    tagline: 'What gets measured gets managed.',
    reflectionPrompt: 'Do you know exactly where your money goes?',
    majorMove: 'Track every dollar you spend for the next 48 hours.'
  },
  {
    id: 'money-02',
    name: 'Think',
    framework: 'money',
    tagline: 'Wealthy minds create wealthy realities.',
    reflectionPrompt: 'What would wealthy-you think about right now?',
    majorMove: 'Read 10 pages from a book on wealth mindset.'
  },
  {
    id: 'money-03',
    name: 'Feel',
    framework: 'money',
    tagline: 'Money responds to energy.',
    reflectionPrompt: 'What emotions come up when you think about money?',
    majorMove: 'Journal about your earliest money memory and how it shaped you.'
  },
  {
    id: 'money-04',
    name: 'Speak',
    framework: 'money',
    tagline: 'Your words are financial contracts.',
    reflectionPrompt: 'Are you speaking abundance or lack?',
    majorMove: 'Replace "I can\'t afford it" with "How can I afford it?" today.'
  },
  {
    id: 'money-05',
    name: 'Ask',
    framework: 'money',
    tagline: 'Closed mouths don\'t get fed.',
    reflectionPrompt: 'What have you been afraid to ask for?',
    majorMove: 'Ask for something you want—a raise, discount, or opportunity.'
  },
  {
    id: 'money-06',
    name: 'Hold',
    framework: 'money',
    tagline: 'Build your reserves.',
    reflectionPrompt: 'How secure do you feel financially?',
    majorMove: 'Set up an automatic transfer to savings, even if it\'s $5.'
  },
  {
    id: 'money-07',
    name: 'Use',
    framework: 'money',
    tagline: 'Money is a tool, not a trophy.',
    reflectionPrompt: 'Is your money working for you or sitting idle?',
    majorMove: 'Research one investment vehicle you\'ve never explored.'
  },
  {
    id: 'money-08',
    name: 'Manifest',
    framework: 'money',
    tagline: 'See it before you see it.',
    reflectionPrompt: 'What does your ideal financial life look like in detail?',
    majorMove: 'Create a vivid vision board or written description of your wealth.'
  },
  {
    id: 'money-09',
    name: 'Attract',
    framework: 'money',
    tagline: 'Be the energy you want to receive.',
    reflectionPrompt: 'Are you embodying abundance in how you show up?',
    majorMove: 'Give something of value today—time, knowledge, or resources.'
  },
  {
    id: 'money-10',
    name: 'Enjoy',
    framework: 'money',
    tagline: 'Wealth is meant to be lived.',
    reflectionPrompt: 'When did you last enjoy money guilt-free?',
    majorMove: 'Spend a small amount on something that brings you pure joy.'
  },

  // TECH Framework - CODEX (The Legacy Engineer)
  {
    id: 'tech-01',
    name: 'Diaspora Empowerment',
    framework: 'tech',
    tagline: 'Build bridges with code.',
    reflectionPrompt: 'How can technology serve your community?',
    majorMove: 'Identify one tech solution that could help your local community.'
  },
  {
    id: 'tech-02',
    name: 'Mindset Shift & Resilience',
    framework: 'tech',
    tagline: 'Debug your mental loops.',
    reflectionPrompt: 'What failure taught you the most about persistence?',
    majorMove: 'Reframe one past tech failure as a lesson and document it.'
  },
  {
    id: 'tech-03',
    name: 'Gamified Education',
    framework: 'tech',
    tagline: 'Learn like you play.',
    reflectionPrompt: 'How can you make learning more engaging?',
    majorMove: 'Complete one coding challenge or tutorial with a gamified platform.'
  },
  {
    id: 'tech-04',
    name: 'Blockchain & Decentralization',
    framework: 'tech',
    tagline: 'Own your data, own your future.',
    reflectionPrompt: 'What systems in your life could benefit from decentralization?',
    majorMove: 'Set up a wallet or explore one blockchain-based application.'
  },
  {
    id: 'tech-05',
    name: 'Community & Collaboration',
    framework: 'tech',
    tagline: 'Code is stronger together.',
    reflectionPrompt: 'Who are you building with?',
    majorMove: 'Contribute to an open-source project or join a tech community.'
  },
  {
    id: 'tech-06',
    name: 'Localized AI & Personalization',
    framework: 'tech',
    tagline: 'AI should amplify you.',
    reflectionPrompt: 'How can AI serve your unique needs and culture?',
    majorMove: 'Customize an AI tool to better serve your workflow or language.'
  },
  {
    id: 'tech-07',
    name: 'Holistic Wellness & Balance',
    framework: 'tech',
    tagline: 'Tech without burnout.',
    reflectionPrompt: 'Is your relationship with technology healthy?',
    majorMove: 'Set up screen time limits or take a 2-hour digital detox.'
  },
  {
    id: 'tech-08',
    name: 'Security & Compliance',
    framework: 'tech',
    tagline: 'Guard your digital kingdom.',
    reflectionPrompt: 'How secure are your most important accounts?',
    majorMove: 'Enable 2FA on your top 3 accounts and review your passwords.'
  },
  {
    id: 'tech-09',
    name: 'Data-Driven Performance & Analytics',
    framework: 'tech',
    tagline: 'Let data light the way.',
    reflectionPrompt: 'What metrics matter most to your goals?',
    majorMove: 'Set up tracking for one personal or professional KPI.'
  },
  {
    id: 'tech-10',
    name: 'Legacy & Long-Term Impact',
    framework: 'tech',
    tagline: 'Build what outlasts you.',
    reflectionPrompt: 'What will you leave behind in the digital world?',
    majorMove: 'Start documenting one project or idea that could impact future generations.'
  },
];

export const getFrameworkPillars = (framework: 'life' | 'money' | 'tech') => 
  pillars.filter(p => p.framework === framework);

export const getPillarById = (id: string) => 
  pillars.find(p => p.id === id);
