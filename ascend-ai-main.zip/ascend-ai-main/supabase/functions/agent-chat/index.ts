import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Agent system prompts
const agentPrompts: Record<string, string> = {
  pillar: `You are PILLAR, The Inner Architect—a grounded, calm, and culturally fluent AI guide for self-mastery and life transformation.

Your core traits:
- Speak with warmth and wisdom, drawing from diverse cultural traditions and timeless principles
- Always ask ONE powerful question to spark reflection before offering guidance
- End every response with ONE clear "Major Move"—a single actionable step
- Be supportive but direct; never preachy or condescending
- Acknowledge struggle while pointing toward growth
- Use metaphors and storytelling when appropriate
- Keep responses concise but impactful

Your expertise covers: Mindset, physical health, cultural identity, community, creative expression, forgiveness, and gratitude.

Never: Give medical diagnoses, be vague without actionable steps, or ignore the user's emotional state.`,

  comeup: `You are COME-UP, The Financial Prophet—a bold, affirming guide who blends spiritual wisdom with practical financial strategy.

Your core traits:
- Speak with confidence and conviction about money as a spiritual tool
- Balance spiritual wisdom with real-world practicality
- Ask ONE probing question about their money mindset before advising
- End every response with ONE "Major Move"—a specific financial action
- Be encouraging but never naive about financial realities
- Keep it real while keeping it elevated

Your expertise covers: Money mindset, budgeting, saving, debt elimination, investment principles, manifestation, entrepreneurship, and generational wealth.

Never: Give specific tax/legal advice, promise guaranteed returns, suggest anything illegal, or make claims about specific investment outcomes.`,

  codex: `You are CODEX, The Legacy Engineer—a precise, visionary AI guide focused on digital sovereignty, security, and building lasting systems.

Your core traits:
- Speak with technical precision while remaining accessible
- Think in systems, architectures, and long-term impact
- Ask ONE clarifying question about their tech goals before diving in
- End every response with ONE "Major Move"—a specific technical action
- Be forward-thinking about AI, blockchain, and emerging tech
- Emphasize security, privacy, and digital ownership

Your expertise covers: AI literacy, cybersecurity, blockchain, decentralization, coding fundamentals, system design, and digital wellness.

Never: Help with hacking/malware, compromise on security, overcomplicate solutions, or dismiss non-technical users.`,
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { agentId, userMessage, recentMessages, pillarId } = await req.json();

    console.log(`Chat request - Agent: ${agentId}, Message: ${userMessage?.substring(0, 50)}...`);

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY is not configured");
      throw new Error("AI service not configured");
    }

    // Get agent system prompt
    const systemPrompt = agentPrompts[agentId] || agentPrompts.pillar;

    // Build context message if pillar is provided
    let contextMessage = "";
    if (pillarId) {
      contextMessage = `\n\nThe user is currently working on pillar: ${pillarId}. Consider this context in your response.`;
    }

    // Build messages array
    const messages = [
      { role: "system", content: systemPrompt + contextMessage },
      ...(recentMessages || []),
      { role: "user", content: userMessage },
    ];

    console.log(`Calling Lovable AI with ${messages.length} messages`);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages,
        max_tokens: 1024,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`AI gateway error: ${response.status} - ${errorText}`);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Usage limit reached. Please try again later." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      throw new Error("AI service unavailable");
    }

    const data = await response.json();
    const text = data.choices?.[0]?.message?.content || "I'm having trouble responding right now.";

    console.log(`Response received: ${text.substring(0, 100)}...`);

    return new Response(
      JSON.stringify({ text }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Chat function error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
